﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAXApp1
{
    internal static class EmployeeService
    {
        public static string? ConnString { get; set; }
    }
}
